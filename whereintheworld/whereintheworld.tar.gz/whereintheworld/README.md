Assignment 3 - Comp 20
Brett Fouss

Where in the World? -- Node.js, HerokuApp, MongoDB

1. I believe that everything has been correctly implemented. I have tested (both locally and on HerokuApp) extensively using a chrome extension called Postman. It allowed me to test both post/get requests pretty easily. I also tested with assignment 2, which still works. The entries are sorted, and in the correct format. 

2. I worked with some classmates - Max, Charlie, and some other people I don't know the names with. A TA (Tuesday night) helped me with mongolab. 

3. This took me a long time to complete! I spend most of my time wrapping my head around the concepts and figuring out how to test my work. I definitely have a much better understanding of server-side programming now. 