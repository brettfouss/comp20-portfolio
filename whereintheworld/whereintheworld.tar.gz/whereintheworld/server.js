var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var http = require('http');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//mongo initialization 
// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/test'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});

//enable cross origin resource sharing
app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.get('/', function (req, res, next) {

  res.set('Content-Type', 'text/html');
  var indexPage = '';

db.collection('locations', function(er, collection) {
      collection.find().sort({_id : -1}).toArray(function(err, cursor) {
      if (!err) {
        indexPage += "<!DOCTYPE HTML><html><head><title>Where in the World?</title></head><body><h1>Where In the World?</h1>";
        for (var n = 0; n < cursor.length && n < 100 ; n++) {
          var json = JSON.parse(JSON.stringify(cursor[n]));
          var outputString = '<p>Login: ' + json.login + '</p><p>Lat: ' + json.lat + '</p><p>Lng: ' + json.lng + '</p><p>Timestamp: ' + json.created_at + '</p>';
          indexPage += "<p><h3>Location " + (n+1) + "</h3>" + outputString + "</p>";
          indexPage += "</body></html>";
        }
          res.send(indexPage);
      } else {
        res.send('<!DOCTYPE HTML><html><head><title>Where in the World?</title></head><body><h1>Error</h1></body></html>');
      }
    });
  });
});

app.get('/locations.json', function(req, res, next) {
  
  res.set('Content-Type', 'text/html');
  var myQuery = req.query;
  var myJSON = JSON.stringify(myQuery);
  var searchString = JSON.parse(myJSON).login;

  var response = [];

  if (searchString != '{}') {
    if (db) { // CHECK FOR THIS 
        db.collection('locations', function(er, collection) {
        collection.find({"login":searchString}).toArray(function(err, cursor) {
          if (!err) {
             for (var n = 0; n < cursor.length && n < 100 ; n++) {
              response[n] = cursor[n];
            }
            res.send(response);
          }
      });
    });
     }
   }
});

app.get('/redline.json', function(request, response) {
  var data = '';
  http.get('http://developer.mbta.com/lib/rthr/red.json', function(apiresponse) {
    apiresponse.on('data', function(chunk) {
      data += chunk;
    });
    apiresponse.on('end', function() {
      response.send(data);
    });
  }).on('error', function(error) {
    response.send(500);
  });
});

app.post('/sendLocation', function (req, res, next) {
  
  var login = req.body.login;
  var lat = parseFloat(req.body.lat);
  var lng = parseFloat(req.body.lng);
  var created_at = new Date().toUTCString();

  if (login && lat && lng) {

    var toInsert = {
       "login": login,
       "lat": lat,
       "lng": lng,
       "created_at": created_at, // COMMA
      };

      //insert into database
      db.collection('locations', function(er, collection) {
        var id = collection.insert(toInsert,function(err, saved) {
          if(err) {
           res.send(500);
          }
        });
      });

    //send response
    var students = [];
    db.collection('locations', function(er, collection) {
      collection.find().sort({_id : -1}).toArray(function(err, cursor) {
        if (!err) {
          for (var n = 0; n < cursor.length && n < 100; n++) {
            students[n] = cursor[n];
          }
          res.send(JSON.stringify({"characters":[],"students":students}));
        }
      });
    });
  }
});

app.listen(process.env.PORT || 3000)